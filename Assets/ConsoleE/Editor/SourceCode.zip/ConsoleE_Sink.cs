// 2014 � Inhuman Games. All rights reserved.
using UnityEngine;
using UnityEditor;
using System;
using System.Collections.Generic;
using System.IO;
using System.Runtime.InteropServices;
using System.Diagnostics;
using System.Reflection;
using System.Xml.Serialization;
using System.Text;
using ConsoleE_Interfaces;

// using namespaces seems to cause Unity (4.2) to not serialize objects as fully, when Editor changes play states.  This could reduce performance slighty and possibly effect stability.
//namespace ConsoleE
//{
    /// <summary>
    /// ConsoleE_Sink is the link between any custom code (context menus, options, etc) with the Console Renderer
    /// </summary>
    [Serializable]
    public class ConsoleE_Sink : IConsoleE_Sink
    {
        #region IConsoleE_Sink Members

        public IConsoleE_Entry CreateEntry(IConsoleE_Renderer console)
        {
            return new ConsoleE_Entry();
        }

        public IConsoleE_Menus CreateMenus(IConsoleE_Renderer console)
        {
            ConsoleE_Menus menus = new ConsoleE_Menus();
            menus.Init(console);
            return menus;
        }

        public IConsoleE_OnClick CreateOnClick(IConsoleE_Renderer console)
        {
            ConsoleE_OnClick onclick = new ConsoleE_OnClick();
            onclick.Init(console);
            return onclick;
        }

        public void ShowOptionsWindow(IConsoleE_Renderer console)
        {
            ConsoleE_OptionsWindow.ShowWindow();
        }

        public static IConsoleE_Sink CreateSink()
        {
            return new ConsoleE_Sink();
        }

        public void OnSelectedEntryChanged(IConsoleE_Entry entry)
        {
            if(ConsoleE_Window.Instance != null)
                ConsoleE_Window.Instance.OnSelectedEntryChanged(entry);
        }

        #endregion
    }
//}
