// 2014 � Inhuman Games. All rights reserved.
//#define PROFILING_CONSOLE
using UnityEngine;
using UnityEditor;
using System;
using System.Collections.Generic;
using System.IO;
using System.Runtime.InteropServices;
using System.Diagnostics;
using System.Reflection;
using System.Xml.Serialization;
using System.Text;
using ConsoleE_Interfaces;

// using namespaces seems to cause Unity (4.2) to not serialize objects as fully, when Editor changes play states.  This could reduce performance slighty and possibly effect stability.
//namespace ConsoleE
//{
    /// <summary>
    /// ConsoleE_Options contains code for storing options and preferences.  The UI code for this class is in ConsoleE_OptionsWindow.
    /// </summary>
    [Serializable]
    public class ConsoleE_Options : IConsoleE_Options
    {
        public static ConsoleE_Options Instance; 

        [Serializable]
        public class WrapperListEntry : IConsoleE_IWrapperListEntry
        {
            [SerializeField] string text;
            public string Text { get { return text; } set { text = value; } }
        }

        /// <summary>
        /// WrapperList contains a list of text entries which are used to determine what is the most relevant callstack entry (first non-wrapper function entry).
        /// The WrapperList is saved to a file in the project because it's considered a project-wide setting (useful for all developers on a project).
        /// </summary>
        [Serializable]
        public class WrapperListOptions : IConsoleE_IWrapperList
        {
            public WrapperListEntry[] EntriesImpl; // making public to help encourage Unity to serialize this instead of setting to null during editor reset
            public IConsoleE_IWrapperListEntry[] Entries { get { return EntriesImpl; } }

            public void Reset()
            {
                EntriesImpl = new WrapperListEntry[0];
            }

            public void SetFromRawText(string wrapperListTextRaw)
            {
                string[] list = wrapperListTextRaw.Split(new char[] {'\n'}, StringSplitOptions.RemoveEmptyEntries); // Environment.NewLine
                EntriesImpl = new WrapperListEntry[list.Length];
                for(int i = 0; i < list.Length; i++)
                {
                    EntriesImpl[i] = new WrapperListEntry();
                    EntriesImpl[i].Text = list[i];
                }
            }

            public string BuildRawText()
            {
                StringBuilder ret = new StringBuilder();

                foreach(WrapperListEntry e in EntriesImpl)
                {
                    ret.Append(e.Text);
                    ret.Append("\n");
                }

                return ret.ToString();
            }

            public static WrapperListOptions LoadWrapperList()
            {
                StreamReader stream = null;

                WrapperListOptions wrapperList = new WrapperListOptions();

                string filenameEntries = null;
            
                try
                {
                    filenameEntries = ConsoleE_Options.GetWrapperListFilenameWithPath();

                    #if PROFILING_CONSOLE
                    // going to disk is slow, so we want to make sure we only do this when necessary (when console is initialized and when using the options window is used)
                    UnityEngine.Debug.LogWarning("Loading " + filenameEntries);
                    #endif


                    stream = System.IO.File.OpenText(filenameEntries);
                    XmlSerializer xml = new XmlSerializer(typeof(WrapperListOptions));
                    wrapperList = (WrapperListOptions) xml.Deserialize(stream);

                    // if deserialize did not recreate the entries, then we need to new this object
                    if(wrapperList.EntriesImpl == null)
                        wrapperList.Reset();
                }
                catch(Exception e)
                {
                    string locationMsg = filenameEntries == null ? "" : "from " + filenameEntries;
                    UnityEngine.Debug.LogError(string.Format("Failed to load ConsoleE wrapper function list {0}\nException:{1}", locationMsg, e.ToString()));
                    wrapperList = new WrapperListOptions();
                    wrapperList.Reset();
                }
                finally
                {
                    if(stream != null)
                        stream.Dispose();
                }

                return wrapperList;
            }

            public void SaveWrapperList()
            {
                string filename = ConsoleE_Options.GetWrapperListFilenameWithPath();

                #if PROFILING_CONSOLE
                UnityEngine.Debug.LogWarning("Saving " + filename);
                #endif

                StreamWriter stream = null;
                try
                {
                    stream = System.IO.File.CreateText(filename);
                    XmlSerializer xml = new XmlSerializer(typeof(WrapperListOptions));
                    xml.Serialize(stream, this);
                }
                catch(Exception e)
                {
                    throw e;
                    //EditorUtility.DisplayDialog("Error saving advanced settings", e.Message, "OK");
                }
                finally
                {
                    if(stream != null)
                        stream.Dispose();
                }
            }

            public void SaveAndUpdateAll()
            {
                SaveWrapperList();
                NotifyUpdated();

                if(ConsoleE_OptionsWindow.Instance != null)
                    ConsoleE_OptionsWindow.Instance.OnWrapperListUpdated();
            }

            public bool AddEntry(string wrapperListEntryText, bool notifyUpdated)
            {
                if(wrapperListEntryText != null && wrapperListEntryText.Length > 0)
                {
                    if(FindEntryByText(wrapperListEntryText) != null)
                        return false;

                    WrapperListEntry[] entriesNew = new WrapperListEntry[EntriesImpl.Length + 1];
                    EntriesImpl.CopyTo(entriesNew, 0);
                    EntriesImpl = entriesNew;

                    var entryNew = new WrapperListEntry();
                    entryNew.Text = wrapperListEntryText;
                    EntriesImpl[EntriesImpl.Length-1] = entryNew;

                    if(notifyUpdated)
                        NotifyUpdated();

                    return true;
                }
                return false;
            }

            public bool RemoveEntry(string wrapperListEntryText, bool notifyUpdated)
            {
                if(wrapperListEntryText != null && wrapperListEntryText.Length > 0 && EntriesImpl.Length > 0)
                {
                    List<WrapperListEntry> list = new List<WrapperListEntry>(EntriesImpl.Length-1);

                    foreach(var e in EntriesImpl)
                    {
                        if(e.Text != wrapperListEntryText)
                            list.Add(e);
                    }

                    if(list.Count == EntriesImpl.Length)
                        return false; // not found

                    EntriesImpl = list.ToArray();

                    if(notifyUpdated)
                        NotifyUpdated();

                    return true;
                }
                return false;
            }

            /// <summary>
            /// Search for an entry with this exact text.  This must be an exact match of the complete string, substring matching should not be done here.
            /// </summary>
            public WrapperListEntry FindEntryByText(string wrapperListEntryText)
            {
                if(wrapperListEntryText != null)
                {
                    foreach(WrapperListEntry e in EntriesImpl)
                    {
                        if(e.Text == wrapperListEntryText)
                            return e;
                    }
                }
                return null;
            }

            public void NotifyUpdated()
            {
                if(ConsoleE_Options.Instance != null)
                {
                    ConsoleE_Options.Instance.NotifyUpdated();
                }
            }
        }

        //const string fileNameThisClass = "ConsoleE_Options.cs";
        const string filenameWrapperList = "ConsoleE_WrapperList"; //"ConsoleE_WrapperList.xml";  putting .xml causes Unity to include this file in your vcproj when it really does not need to be there.

        public WrapperListOptions WrapperListImpl; // making public to help encourage Unity to serialize this instead of setting to null during editor reset
        public IConsoleE_IWrapperList WrapperList { get { return WrapperListImpl; } }


        string projectAssetPath; // storing this because I think saw a case where Unity was not consistant with the return value for Application.dataPath

        public string ProjectAssetPath
        { 
            get
            {
                if(string.IsNullOrEmpty(projectAssetPath))
                {
                    projectAssetPath = Application.dataPath;
                    if(!projectAssetPath.EndsWith(Path.DirectorySeparatorChar.ToString()) && !projectAssetPath.EndsWith(Path.AltDirectorySeparatorChar.ToString()))
                        projectAssetPath += "/"; // consistant with Unity always using forward slashes
                        //projectAssetPath += Path.DirectorySeparatorChar;
                }
                return projectAssetPath;
            }
        }

        public bool SkipWrapperListEntries { get { return skipWrapperListEntries; } set { skipWrapperListEntries = value; } }
        [SerializeField] bool skipWrapperListEntries;

        public bool HideFilePathsInMainArea { get { return hideFilePathsInMainArea ; } set { hideFilePathsInMainArea = value; } }
        [SerializeField] bool hideFilePathsInMainArea;

        public bool HideFilePathsInCallstackArea { get { return hideFilePathsInCallstackArea; } set { hideFilePathsInCallstackArea = value; } }
        [SerializeField] bool hideFilePathsInCallstackArea;
            
        public bool IsOverridingExternalApp { get { return isOverridingExternalApp; } set { isOverridingExternalApp = value; } }
        [SerializeField] bool isOverridingExternalApp;

        public string OverrideExternalApp { get { return overrideExternalApp; } set {overrideExternalApp = value;} }
        [SerializeField] string overrideExternalApp;

        public string OverrideArgsFormatString { get { return overrideArgsFormatString; } set { overrideArgsFormatString = value;} }
        [SerializeField] string overrideArgsFormatString;
            
        /// <summary>
        /// If true, user can right click on entries in the main area, and a context menu will show.
        /// </summary>
        public bool EnableRightClickMenuInMainArea { get { return true; } }

        /// <summary>
        /// If true, and if the first line of the callstack is longer than the width of the console window, the first line will be wrapped, creating new rows in the callstack area.
        /// </summary>
        public bool IsWrappingFirstLineOfCallstack { get { return true; } }

        /// <summary>
        /// Normally, the user can move the internal window inside the main area with a mouse drag.  If this returns false, this feature will be disabled.
        /// </summary>
        public bool EnableDragScrolling { get { return true; } } 

        public string RemoveFilePathFromEndOfLine(string line)
        {
            if(line.EndsWith(")"))
            {
                int index = line.LastIndexOf(" (at ");
                if(index != -1)
                    line = line.Substring(0, index);
            }
            return line;
        }

        public float MouseWheelScrollSpeed_MainArea 
        {
            get
            {
                return 1.0f;
            }
        }

        public float MouseWheelScrollSpeed_CallstackArea 
        {
            get
            {
                return 1.0f;
            }
        }

        /// <summary>
        /// The user can move the internal window inside the main area with a mouse drag.  This function describes how quickly that internal window will snap back to its normal position once the mouse is released.
        /// </summary>
        /// <param name="distanceToGo">Distance between current position and normal position.</param>
        /// <returns>Distance to move this frame.</returns>
        public float SpeedDragScrollReturnsToNormalPos(float distanceToGo, float timeSinceLastUpdate)
        {
            return timeSinceLastUpdate * Mathf.Pow(distanceToGo, 0.75f) * 30.0f;
        }

        /* no custom constructors!  Unity's serializer does not like this.  Use Init() instead.
        public ConsoleE_Options()
        {
        }
        */

        public void Init()
        {
            ConsoleE_Options.Instance = this;

            LoadUserOptions();

            WrapperListImpl = WrapperListOptions.LoadWrapperList();
        }

        void LoadUserOptions()
        {
            skipWrapperListEntries = EditorPrefs.GetBool("ConsoleE_SkipWrapperListEntries", false);
            hideFilePathsInMainArea = EditorPrefs.GetBool("ConsoleE_HideFilePathsInMainArea", false);
            hideFilePathsInCallstackArea = EditorPrefs.GetBool("ConsoleE_HideFilePathsInCallstackArea", false);
            overrideExternalApp = EditorPrefs.GetString("ConsoleE_OverrideExternalApp", "");
            overrideArgsFormatString = EditorPrefs.GetString("ConsoleE_OverrideArgsFormatString", "");
            isOverridingExternalApp = EditorPrefs.GetBool("ConsoleE_IsOverridingExternalApp", !string.IsNullOrEmpty(OverrideExternalApp));
        }

        public void Save()
        {
            Save(true);
        }

        public void Save(bool refreshProjectWindow)
        {
            SaveUserOptions();

            WrapperListImpl.SaveWrapperList();

            //if(refreshProjectWindow)
            {
                // The xml file has no xml extension (by design), so Unity will not shown the file contents to user, so there's no point to refreshing here
                //System.Threading.Thread.Sleep(100); // wait a bit before refresh, in case system is slow
                //AssetDatabase.Refresh(); // refresh so if you click on this file in the project window, you'll see its contents were updated
            }
        }

        void SaveUserOptions()
        {
            EditorPrefs.SetBool("ConsoleE_SkipWrapperListEntries", SkipWrapperListEntries);
            EditorPrefs.SetBool("ConsoleE_HideFilePathsInMainArea", HideFilePathsInMainArea);
            EditorPrefs.SetBool("ConsoleE_HideFilePathsInCallstackArea", HideFilePathsInCallstackArea);
            EditorPrefs.SetString("ConsoleE_OverrideExternalApp", OverrideExternalApp);
            EditorPrefs.SetString("ConsoleE_OverrideArgsFormatString", OverrideArgsFormatString);
            EditorPrefs.SetBool("ConsoleE_IsOverridingExternalApp", IsOverridingExternalApp);
        }

        public void SetWrapperListFromRawText(string wrapperListTextRaw)
        {
            WrapperListImpl.SetFromRawText(wrapperListTextRaw);
        }

        public string BuildRawTextFromWrapperList()
        {
            if(WrapperListImpl == null)
                return "";
            return WrapperListImpl.BuildRawText();
        }

        public bool IsInitializationNeeded() // sometimes when the editor is restarted, reserialization does not fully recreate the object instance
        {
            return WrapperListImpl == null;
        }

        static string DeterminePathToOptionsFile()
        {
            // find the path that contains our options file

            string path = Instance != null ? Instance.ProjectAssetPath : Application.dataPath + "/";

            try
            {
                if(ConsoleE_Window.Instance == null)
                {
                    throw new Exception("ConsoleE Window instance is null");
                }

                var script = MonoScript.FromScriptableObject(ConsoleE_Window.Instance);

                string scriptDirectory = System.IO.Path.GetDirectoryName(AssetDatabase.GetAssetPath(script));

                // remove duplicate "Assets" folder
                if(scriptDirectory.StartsWith("Assets", StringComparison.InvariantCultureIgnoreCase))
                {
                    scriptDirectory = scriptDirectory.Substring(7);
                }

                if(!scriptDirectory.EndsWith(Path.DirectorySeparatorChar.ToString()) && !scriptDirectory.EndsWith(Path.AltDirectorySeparatorChar.ToString()))
                    scriptDirectory += "/"; // consistant with Unity always using forward slashes

                string ret = path + scriptDirectory;

                string fullfilename = ret + filenameWrapperList;

                //
                // check to see if we need to create a new wrapper list settings file
                // this list is saved as a file to give project owners the option of 
                // sharing the wrapper list project-wide 
                // (if they add the ignorelist file to version control).
                //
                if(!File.Exists(fullfilename))
                {
                    string newFile =
@"<?xml version=""1.0"" encoding=""utf-8""?>
<WrapperListOptions xmlns:xsi=""http://www.w3.org/2001/XMLSchema-instance"" xmlns:xsd=""http://www.w3.org/2001/XMLSchema"">
  <EntriesImpl />
</WrapperListOptions>";

                    try
                    {
                        System.IO.File.WriteAllText(fullfilename, newFile);
                    }
                    catch(Exception e)
                    {
                        UnityEngine.Debug.LogError(string.Format("Failed to create wrapper function list file at {0}", fullfilename));
                        throw e;
                    }

                    AssetDatabase.StartAssetEditing();
                    AssetDatabase.ImportAsset(fullfilename);
                    AssetDatabase.StopAssetEditing();

                    System.Threading.Thread.Sleep(100); // wait a bit before refresh, in case system is slow
                    AssetDatabase.Refresh();

                    //
                    // get context to show user where file is at
                    // in order to get this context, we have to search through all resources
                    //
                    UnityEngine.Object context = null;

                    int maxTries = 2;
                    for(int i = 0; i < maxTries; i++)
                    {
                        if(context == null)
                        {
                            /* this works but is overkill
                            UnityEngine.Object[] list = Resources.FindObjectsOfTypeAll(typeof(UnityEngine.Object));
                            foreach(var v in list)
                            {
                                if(v.name == filenameWrapperList)
                                {
                                    context = v;
                                    break;
                                }
                            }
                            */
                            
                            // LoadAssetAtPath wants a relative path
                            context = AssetDatabase.LoadAssetAtPath(Path.Combine(Path.Combine("Assets", scriptDirectory), filenameWrapperList), typeof(UnityEngine.Object));
                        }

                        if(context != null)
                            break;

                        // this doesn't seem to be needed anymore, but I'm leaving it here, just in case
                        if(i != maxTries-1)
                        {
                            System.Threading.Thread.Sleep(1000); // wait a bit before refresh, in case system is slow
                            AssetDatabase.Refresh(); 
                        }
                    }

                    if(context != null)
                        Selection.activeObject = context;

                    string msg = string.Format("ConsoleE created a settings file for project-specific settings.\nThis file is normally created the first time ConsoleE is used in a particular project.\nSettings file is located here (at {0}:0)", fullfilename);
                    UnityEngine.Debug.Log(msg, context);
                    //throw new FileNotFoundException(test);
                }
                             
                //UnityEngine.Debug.Log("Found at = " + test);

                return ret;
            }
            catch(Exception exceptionOriginal)
            {
                #if TESTING_CONSOLE
                UnityEngine.Debug.LogError(exceptionOriginal);
                #endif

                // plan B, only works if user did not move ConsoleE
                // this way works, but Unity returns forward slashs on Windows, so let's hardcode forward slashes so all seperators are consistant
                //string ret = path + "ConsoleE" + Path.DirectorySeparatorChar + "Editor" + Path.DirectorySeparatorChar;
                string ret = path + "ConsoleE/Editor/";

                // if plan B doesn't work, then show the exception from plan A
                if(!File.Exists(ret + filenameWrapperList))
                {
                    UnityEngine.Debug.LogError(exceptionOriginal);
                    throw new Exception(string.Format("Could not figure out where ConsoleE's options file is located.  One solution to this problem is to put ConsoleE options file ({0}) in this folder: {1}", filenameWrapperList, ret));
                }

                return ret;
            }
        }

        public static string GetWrapperListFilenameWithPath()
        {
            return DeterminePathToOptionsFile() + filenameWrapperList;
        }

        public void NotifyUpdated()
        {
            var w = ConsoleE_Window.Instance;
            if(w != null)
            {
                w.OnOptionsUpdated(this);
            }
        }

        /*
        public string SecondaryExternalEditorPath
        {
            get 
            {
                return EditorPrefs.GetString("ConsoleE_SecondaryExternalEditor");
            }
        }

        public bool UseSecondaryExternalEditorForLeftClick
        {   
            get
            {
                return EditorPrefs.GetBool("ConsoleE_UseSecondaryExternalEditorForLeftClick", false);
            }

            set
            {
                EditorPrefs.SetBool("ConsoleE_UseSecondaryExternalEditorForLeftClick", value);
            }
        }
        */
    }
//}
