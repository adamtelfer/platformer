// 2014 � Inhuman Games. All rights reserved.
using UnityEngine;
using UnityEditor;
using System;
using System.Collections.Generic;
using System.IO;
using System.Runtime.InteropServices;
using System.Diagnostics;
using System.Reflection;
using System.Xml.Serialization;
using System.Text;
using ConsoleE_Interfaces;

// using namespaces seems to cause Unity (4.2) to not serialize objects as fully, when Editor changes play states.  This could reduce performance slighty and possibly effect stability.
//namespace ConsoleE
//{
    /// <summary>
    /// ConsoleE_Menus is provided to allow you to override the behavior of the default context menus.
    /// </summary>
    [Serializable]
    public class ConsoleE_Menus : IConsoleE_Menus
    {
        //[MenuItem("Window/Console Enhanced %#&C", priority = 2200)]  // 2200 causes this MenuItem to be placed next to Windows->Console in the Unity editor menu
        [MenuItem("Window/Console Enhanced %#c", priority = 2199)]  // 2200 causes this MenuItem to be placed next to Windows->Console in the Unity editor menu
	    static void ShowConsoleEnhancedWindow()
        {
            ConsoleE_Window.ShowMainWindow();
        }

        /* no custom constructors!  Unity's serializer does not like this.  Use Init() instead.
        public ConsoleE_Menus()
        {
        }
        */

        public void Init(IConsoleE_Renderer renderer)
        {
            this.renderer = renderer;
        }

        public void OnMainWindowEnabled(IConsoleE_Renderer renderer)
        {
            this.renderer = renderer;
        }

        IConsoleE_Renderer renderer;
        IConsoleE_Entry selectedEntry { get { return renderer.SelectedEntry; } }
        public ConsoleE_Entry SelectedEntry { get { return renderer.SelectedEntry as ConsoleE_Entry; } }
        int indexSelectedCallstackRow { get { return renderer.IndexSelectedCallstackRow; } }

        public static void CopyToClipboard(string text)
        {
            if(text != null)
            {
                TextEditor te = new TextEditor();
                te.content = new GUIContent(text);
                te.SelectAll();
                te.Copy();
            }
        }

        /// <summary>
        /// Called when user has right-clicked in the callstack area of the console window
        /// </summary>
        public void ShowMenu_CallstackRightClick(Nullable<Vector2> positionOverride)
        {
            if(SelectedEntry != null && 
                (indexSelectedCallstackRow >= 0 && indexSelectedCallstackRow < SelectedEntry.Rows.Length ||
                renderer.IsPartialTextSelectionActive
                ))
            {
                GenericMenu menu = new GenericMenu();

                string filename = renderer.IndexTextSelectionRowStart == -1 ? GetFilenameSelected(indexSelectedCallstackRow) : null;

                bool openEnabled = filename != null || (selectedEntry != null && selectedEntry.IsRowOpenable(indexSelectedCallstackRow)); // file exists locally

                PopulateOpenMenus(menu, openEnabled, OnCallstackMenu_Open, OnCallstackMenu_OpenWith);

                menu.AddSeparator("");

                if(indexSelectedCallstackRow != -1 || renderer.IndexTextSelectionRowStart != -1)
                {
                    menu.AddItem(new GUIContent("Copy"), false, OnCallstackMenu_Copy);
                }
                else
                {
                    menu.AddDisabledItem(new GUIContent("Copy"));
                }

                /*  Seems like most apps dont add "Select All" to context menus, even if they are available as a hotkey (Ctrl+A)
                if(selectedEntry != null)
                    menu.AddItem(new GUIContent("Select All"), false, OnCallstackMenu_SelectAll);
                else
                    menu.AddDisabledItem(new GUIContent("Select All"));
                */

                menu.AddSeparator("");

                string wrapperTextTitle = selectedEntry != null ? selectedEntry.ParseCallstackRowForWrapperTextTitle(indexSelectedCallstackRow) : null;

                bool handled = false;

                if(wrapperTextTitle != null && indexSelectedCallstackRow != -1 && ConsoleE_Options.Instance != null)
                {
                    string textOriginal = wrapperTextTitle;
                    //if(wrapperTextTitle.Length > 25)
                        //wrapperTextTitle = wrapperTextTitle.Substring(0, 20) + "...";

                    bool alreadyExists = ConsoleE_Options.Instance.WrapperListImpl.FindEntryByText(textOriginal) != null;

                    if(!alreadyExists && !selectedEntry.IsRowInWrapperList(indexSelectedCallstackRow))
                    {
                        menu.AddItem(new GUIContent("Mark As Wrapper Function"), false, OnCallstackMenu_Ignore);
                        handled = true;
                    }
                    else
                    {
                        if(alreadyExists)
                        {
                            menu.AddItem(new GUIContent("Unmark As Wrapper Function"), false, OnCallstackMenu_UndoIgnore);
                            handled = true;
                        }
                    }
                }

                if(!handled)
                {
                    menu.AddDisabledItem(new GUIContent("Mark As Wrapper Function"));
                }

                string showtext;

                if(filename != null)// && ConsoleE_Options.Options.HideFilePathsInCallstackArea)
                {
                    if(filename.Length > 40)
                        filename = filename.Substring(0, 35) + "...";
                    showtext = "Show " + filename;
                }
                else
                    showtext = "Show in Project";

                if(filename != null) // file exists locally
                {
                    menu.AddItem(new GUIContent(showtext), false, OnCallstackMenu_SelectFile);
                }
                else
                {
                    menu.AddDisabledItem(new GUIContent(showtext));
                }

                //menu.AddSeparator("");

                
                //menu.AddItem(new GUIContent("Options"), false, OnShowConsoleOptions);

                if(positionOverride == null)
                    menu.ShowAsContext();
                else
                    menu.DropDown(new Rect(positionOverride.Value.x, positionOverride.Value.y, 0, 0));
            }
            else
            {
                ShowSimpleOptionsMenu();
            }
        }

        void PopulateOpenMenus(GenericMenu menu, bool openEnabled, GenericMenu.MenuFunction onMenu_Open, GenericMenu.MenuFunction2 onMenu_OpenWith)
        {
            if (openEnabled)
            {
                string[] editors = renderer.GetExternalEditorList_Names();

                menu.AddItem(new GUIContent("Open"), false, onMenu_Open);

                for (int i = 0; i < editors.Length; i++)
                {
                    menu.AddItem(new GUIContent("Open with/" + editors[i]), false, onMenu_OpenWith, i);
                }

                if(Application.platform == RuntimePlatform.WindowsEditor) // it seems, adding a seperator on OSX seems causes the submenu to become disabled
                    menu.AddSeparator("Open with/");

                menu.AddItem(new GUIContent("Open with/Preferences"), false, OnOpenWith_Preferences);
            }
            else
            {
                menu.AddDisabledItem(new GUIContent("Open"));
                menu.AddDisabledItem(new GUIContent("Open with"));
            }
        }

        void OnCallstackMenu_Open()
        {
            renderer.ClickSelectedCallstackRow();
        }

        void OnCallstackMenu_OpenWith(object userData)
        {
            int index = (int) userData;
            string externalEditorPath = renderer.GetExternalEditorPath(index);
            renderer.ClickSelectedCallstackRow_OpenWith(externalEditorPath, index);
        }

        void OnOpenWith_Preferences()
        {
            renderer.ShowExternalEditorPreferencesWindow();
        }

        void OnCallstackMenu_SelectFile()
        {
            string filename = selectedEntry.GetCallstackFilename(indexSelectedCallstackRow, IConsoleE_PathTypes.RelativePath);
            if(filename != null)
            {
                // highlight file in project window
                UnityEngine.Object obj = AssetDatabase.LoadAssetAtPath(filename, typeof(UnityEngine.Object));
                if(obj != null)
                    EditorGUIUtility.PingObject(obj);
            }
        }

        void OnCallstackMenu_Copy()
        {
            CopyCallstack();
        }

        public bool IsCommandValid_Copy(IConsoleE_WindowArea windowArea)
        {
            if(windowArea == IConsoleE_WindowArea.MainArea || windowArea == IConsoleE_WindowArea.CallstackArea)
                return selectedEntry != null;
            return false;
        }

        public bool UseCommand_Copy(IConsoleE_WindowArea windowArea)
        {
            if(windowArea == IConsoleE_WindowArea.CallstackArea)
                return CopyCallstack();
            if(windowArea == IConsoleE_WindowArea.MainArea)
                return CopySelectedMainEntryToClipboard();
            return false;
        }

        public bool UseCommand_SelectAll(IConsoleE_WindowArea windowArea)
        {
            if(windowArea == IConsoleE_WindowArea.CallstackArea)
                return SelectAllCallstack();
            return false;
        }

        public bool CopyCallstack()
        {
            if(selectedEntry == null)
                return false;

            if(renderer.IndexTextSelectionRowStart == -1 || renderer.IndexTextSelectionRowEnd == -1)
            {
                CopyToClipboard(selectedEntry.GetCallstackRowTextForRendering(indexSelectedCallstackRow, false));
            }
            else
            {
                StringBuilder sb = new StringBuilder();

                // handle first line of selection
                string textStart = selectedEntry.GetCallstackRowTextForRendering(renderer.IndexTextSelectionRowStart, true);

                int iColStart = (renderer.IndexTextSelectionColStart > 0 && renderer.IndexTextSelectionColStart != int.MaxValue) ? renderer.IndexTextSelectionColStart : 0;
                int iColEnd = (renderer.IndexTextSelectionColEnd > 0 && renderer.IndexTextSelectionColEnd != int.MaxValue) ? renderer.IndexTextSelectionColEnd : int.MaxValue;

                int iRowEnd = renderer.IndexTextSelectionRowEnd == int.MaxValue ? selectedEntry.RowsRendered.Length - 1 : renderer.IndexTextSelectionRowEnd;

                if(renderer.IndexTextSelectionRowEnd == renderer.IndexTextSelectionRowStart)
                {
                    if(iColEnd == int.MaxValue)
                        sb.AppendLine(textStart.Substring(iColStart));
                    else
                        sb.AppendLine(textStart.Substring(iColStart, iColEnd-iColStart));
                }
                else
                {
                    sb.AppendLine(textStart.Substring(iColStart));
                }

                // handle middle lines of selection
                for(int i = renderer.IndexTextSelectionRowStart + 1; i < iRowEnd; i++)
                {
                    sb.AppendLine(selectedEntry.GetCallstackRowTextForRendering(i));
                }

                // handle last line of selection
                if(iRowEnd != renderer.IndexTextSelectionRowStart)
                {
                    string textEnd = selectedEntry.GetCallstackRowTextForRendering(iRowEnd);
                    if(iColEnd != int.MaxValue)
                        sb.AppendLine(textEnd.Substring(0, renderer.IndexTextSelectionColEnd));
                    else
                        sb.AppendLine(textEnd);
                }

                // send text to clipboard
                CopyToClipboard(sb.ToString());
            }

            return true;
        }

        void OnCallstackMenu_SelectAll()
        {
            SelectAllCallstack();
        }

        public bool IsCommandValid_SelectAll(IConsoleE_WindowArea windowArea)
        {
            if(windowArea == IConsoleE_WindowArea.CallstackArea)
                return true;
            return false;
        }

        public bool SelectAllCallstack()
        {
            if(selectedEntry != null)
            {
                renderer.IndexTextSelectionRowStart = 0;
                // maxvalue because resizing can change the number of rows (due to text wrapping)
                renderer.IndexTextSelectionRowEnd = int.MaxValue; // selectedEntry.RowsRendered.Length - 1;
                renderer.IndexTextSelectionColStart = -1;
                renderer.IndexTextSelectionColEnd = -1;
                return true; // true == event.Use();
            }
            return false;
        }

        void OnCopyMainEntryToClipboard()
        {
            CopySelectedMainEntryToClipboard();
        }

        bool CopySelectedMainEntryToClipboard()
        {
            if(selectedEntry != null)
            {
                StringBuilder sb = new StringBuilder();
                for(int i = 0; i < selectedEntry.Rows.Length; i++)
                {
                    sb.AppendLine(selectedEntry.GetCallstackRowTextForRendering(i));
                }
                CopyToClipboard(sb.ToString());
                return true;
            }
            return false;
        }

        void OnCallstackMenu_Ignore()
        {
            if(SelectedEntry != null && ConsoleE_Options.Instance != null)
            {
                var list = ConsoleE_Options.Instance.WrapperListImpl;
                if(list != null)
                {
                    if(list.AddEntry(SelectedEntry.ParseCallstackRowForIgnoreTextEntry(indexSelectedCallstackRow), false))
                    {
                        list.SaveAndUpdateAll();
                    }
                }
            }
        }

        void OnCallstackMenu_UndoIgnore()
        {
            if(SelectedEntry != null && ConsoleE_Options.Instance != null)
            {
                var list = ConsoleE_Options.Instance.WrapperListImpl;
                if(list != null)
                {
                    if(list.RemoveEntry(SelectedEntry.ParseCallstackRowForIgnoreTextEntry(indexSelectedCallstackRow), false))
                    {
                        list.SaveAndUpdateAll();
                    }
                }
            }
        }

        /// <summary>
        /// This menu is shown when Console is right-clicked.
        /// </summary>
        /// <param name="menu"></param>
        public static void MainWindowCustomMenu(GenericMenu menu)
        {
            if(Application.platform == RuntimePlatform.OSXEditor)
            {
                menu.AddItem
                (
                    new GUIContent("Open Player Log"), false, () => 
                    {
                        UnityEditorInternal.InternalEditorUtility.OpenPlayerConsole();
                    }
			    );
            }

			menu.AddItem
			(
                new GUIContent("Open Editor Log"), false, () => 
                {
                    UnityEditorInternal.InternalEditorUtility.OpenEditorConsole();
                }
            );

            menu.AddItem(new GUIContent("Options"), false, OnShowConsoleOptions);
        }

        /// <summary>
        /// Called when user has right-clicked on the console toolbar (or tabs).
        /// </summary>
        public void ShowMenu_ToolbarRightClick()
        {
            ShowSimpleOptionsMenu();
        }

        /// <summary>
        /// Called when user has right-clicked in the main area of the console window, if the option EnableRightClickMenuInMainArea is enabled.
        /// </summary>
        public void ShowMenu_MainAreaRightClick(Nullable<UnityEngine.Vector2> positionOverride)
        {
            if(SelectedEntry != null)
            {
                GenericMenu menu = new GenericMenu();

                bool openEnabled = SelectedEntry.RowHasAction(0);

                PopulateOpenMenus(menu, openEnabled, OnMainMenu_Open, OnMainMenu_OpenWith);

                if(SelectedEntry.IsUnityObjectHiddenInHierarchy)
                {
                    menu.AddSeparator("");
                    menu.AddItem(new GUIContent("Select Hidden Object"), false, SelectedEntry.SelectObjectByInstanceId);
                }

                menu.AddSeparator("");
                menu.AddItem(new GUIContent("Copy"), false, OnCopyMainEntryToClipboard);

                //menu.AddItem(new GUIContent("Options"), false, OnShowConsoleOptions);
                if(positionOverride == null)
                    menu.ShowAsContext();
                else
                    menu.DropDown(new Rect(positionOverride.Value.x, positionOverride.Value.y, 0, 0));
            }
            else
            {
                ShowSimpleOptionsMenu();
            }
        }

        void ShowSimpleOptionsMenu()
        {
            GenericMenu menu = new GenericMenu();

            MainWindowCustomMenu(menu);

            menu.ShowAsContext();
        }

        void OnMainMenu_Open()
        {
            renderer.ClickSelectedMainEntry();
        }

        void OnMainMenu_OpenWith(object userData)
        {
            int index = (int) userData;
            string externalEditorPath = renderer.GetExternalEditorPath(index);
            renderer.ClickSelectedMainEntry_OpenWith(externalEditorPath, index);
        }

        void OnMainMenu_CopyFirstLine()
        {
            CopyToClipboard(selectedEntry.GetCallstackRowTextForRendering(0));
        }

        static void OnShowConsoleOptions()
        {
            ConsoleE_OptionsWindow.ShowWindow();
        }

        string GetFilenameSelected(int iRowCallstack)
        {
            if(selectedEntry == null)
                return null;

            string filename = selectedEntry.GetCallstackFilename(iRowCallstack, IConsoleE_PathTypes.OnlyFilename);

            // if user double-clicked callstack iRow == 0, and this row has no file (which is usual), then pretend like the user
            // clicked the main entry in the main area of the console window (instead of doing nothing).
            if(filename == null && iRowCallstack == 0 && selectedEntry.IndexPrimaryRow > 0)
            {
                filename = selectedEntry.GetCallstackFilename(selectedEntry.IndexPrimaryRow, IConsoleE_PathTypes.OnlyFilename);
            }

            return filename;
        }
    }
//}
