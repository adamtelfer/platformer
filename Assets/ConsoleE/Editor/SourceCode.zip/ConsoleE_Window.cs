// 2014 � Inhuman Games. All rights reserved.
//#define PROFILING_CONSOLE
using UnityEngine;
using UnityEditor;
using System;
using System.Collections.Generic;
using System.IO;
using System.Runtime.InteropServices;
using System.Diagnostics;
using System.Reflection;
//using ConsoleE_Interfaces;

#if !UNITY_EDITOR
// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("ConsoleE")]
[assembly: AssemblyDescription("Console Enhanced is a replacement for Unity's built-in Console. This Assembly contains high-level functionality of ConsoleE.")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Inhuman Games")]
[assembly: AssemblyProduct(ConsoleE_Renderer.ProductNameWithVersionSuffix)]
[assembly: AssemblyCopyright("Copyright � Inhuman Games 2014")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

// Setting ComVisible to false makes the types in this assembly not visible 
// to COM components.  If you need to access a type in this assembly from 
// COM, set the ComVisible attribute to true on that type.
[assembly: ComVisible(false)]

// The following GUID is for the ID of the typelib if this project is exposed to COM
[assembly: Guid("3eb21ed7-9596-4008-b47d-559a886eeace")]

// Version information for an assembly consists of the following four values:
//
//      Major Version
//      Minor Version 
//      Build Number
//      Revision
//
// You can specify all the values or you can default the Build and Revision Numbers 
// by using the '*' as shown below:
// [assembly: AssemblyVersion("1.0.*")]
[assembly: AssemblyVersion(ConsoleE_Renderer.VersionString)] // for example: "1.0.0.0"
[assembly: AssemblyFileVersion(ConsoleE_Renderer.VersionString)] // for example: "1.0.0.0"
#endif

#if UNITY_3_0 || UNITY_3_1 || UNITY_3_2 || UNITY_3_3 || UNITY_3_4 || UNITY_3_5 || UNITY_3_6 || UNITY_3_7 || UNITY_3_8 || UNITY_3_9
#warning Targeting Unity 3.X - UnityEditor.IHasCustomMenu is not supported in Unity 3.X
public interface IHasCustomMenu
{
    void AddItemsToMenu(GenericMenu menu);
}
#else
#warning Targeting Unity 4.X or later - making use of UnityEditor.IHasCustomMenu.  If building a DLL, it will not work in Unity 3.X
#endif

// using namespaces seems to cause Unity (4.2) to not serialize objects as fully, when Editor changes play states.  This could reduce performance slighty and possibly effect stability.
//namespace ConsoleE
//{
    /// <summary>
    /// ConsoleE_Window is the main object for the ConsoleE.  
    /// This class wraps ConsoleE_Renderer which contains low-level rendering code.
    /// </summary>                                                  
    [Serializable]
    public class ConsoleE_Window : UnityEditor.EditorWindow, IHasCustomMenu

    {
        public ConsoleE_Renderer Renderer;
        bool initializedSerializableFields = false;
        public RendererParamsImpl RendererParams;

        #if PROFILING_CONSOLE
        Stopwatch stopwatch;
        int counterStopwatch;
        #endif

        [Serializable]
        public class RendererParamsImpl : IConsoleE_RendererParams // storing a references here to preserve object between editor state changes
        {
            public ConsoleE_Sink Sink;
            public ConsoleE_Options Options;
            public ConsoleE_OnClick OnClick;
            public ConsoleE_Menus Menus;
            public ConsoleE_Entry SelectedEntry; 
            public ConsoleE_Window MainWindow;

            public void OnOptionsUpdatedPrivate(ConsoleE_Options options)
            {
                Options = options;

                if(SelectedEntry != null)
                    SelectedEntry.OnOptionsUpdated(options, MainWindow.Renderer);
            }
            
            public void OnOptionsUpdated(ConsoleE_Options options)
            {
                MainWindow.OnOptionsUpdated(options);
            }

            public void OnMainWindowEnabled(ConsoleE_Window window) // recreate objects as needed after editor state change (sometimes Unity will set them to null between Editor state changes)
            {
                //UnityEngine.Debug.Log("OnMainWindowEnabled");
                MainWindow = window;

                if(window.Renderer == null)
                {
                    window.Renderer = new ConsoleE_Renderer();
                    #if PROFILING_CONSOLE
                    UnityEngine.Debug.Log("Recreated ConsoleE_Renderer");
                    #endif
                }

                if(Options == null || Options.IsInitializationNeeded())
                {
                    Options = ConsoleE_OptionsWindow.LoadOptions();

                    //Options = ConsoleE_OptionsWindow.Options;
                    #if PROFILING_CONSOLE
                    UnityEngine.Debug.Log("Recreated Options");
                    #endif
                }

                OnOptionsUpdated(Options);

                if(Sink == null) 
                {
                    Sink = new ConsoleE_Sink();
                    #if PROFILING_CONSOLE
                    UnityEngine.Debug.Log("Recreated ConsoleE_Sink");
                    #endif
                }

                if(OnClick == null) 
                {
                    OnClick = new ConsoleE_OnClick();
                    OnClick.Init(window.Renderer);
                    #if PROFILING_CONSOLE
                    UnityEngine.Debug.Log("Recreated OnClick");
                    #endif
                }
                else
                {
                    OnClick.OnMainWindowEnabled(window.Renderer);
                }

                if(Menus == null) 
                {
                    Menus = new ConsoleE_Menus();
                    Menus.Init(window.Renderer);
                    #if PROFILING_CONSOLE
                    UnityEngine.Debug.Log("Recreated Menus");
                    #endif
                }
                else
                {
                    Menus.OnMainWindowEnabled(window.Renderer);
                }
            }

            #region IConsoleE_RendererParams Members

            IConsoleE_Menus IConsoleE_RendererParams.Menus
            {
                get { return Menus; }
            }

            IConsoleE_OnClick IConsoleE_RendererParams.OnClick
            {
                get { return OnClick; }
            }

            IConsoleE_Options IConsoleE_RendererParams.Options
            {
                get { return Options; }
            }

            IConsoleE_Sink IConsoleE_RendererParams.Sink
            {
                get { return Sink; }
            }

            IConsoleE_Entry IConsoleE_RendererParams.SelectedEntry 
            { 
                get { return SelectedEntry; } 
            }

            EditorWindow IConsoleE_RendererParams.MainWindow
            {
                get { return MainWindow; }
            }

            #endregion
        }

        /// <summary>
        /// Creates Console Enhanced window or shows the existing one if one already exists.
        /// ConsoleE.Instance is set when the window is created.
        /// </summary>
        /// <param name="typeSinkClass">type of a class that inherits IConsoleE_Sink</param>
	    public static void ShowMainWindow()
        {
            ConsoleE_Window window = Instance != null ? Instance : ScriptableObject.CreateInstance(typeof(ConsoleE_Window)) as ConsoleE_Window;
            window.Show();
            window.Focus();
        }

        /// <summary>
        /// Singleton instance of the ConsoleE window.  This is null if the window is not yet created.
        /// </summary>
        public static ConsoleE_Window Instance;

        void OnDestroy()
        {
            if(Instance == this)
                Instance = null;
        }

        void OnEnable()
        {
            InitNonSerializableFields_Early();

            if(!initializedSerializableFields) 
            {
                InitSerializableFields();
                initializedSerializableFields = true;
            }

            InitNonSerializableFields();

            Renderer.OnEnable(RendererParams);

            #if PROFILING_CONSOLE
            stopwatch = new Stopwatch();
            counterStopwatch = 0;
            #endif
        }

        void OnDisable()
        {
            if(Renderer != null)
                Renderer.OnDisable();
        }

        void Update()
        {
            if(Renderer != null)
                Renderer.Update();
        }

        void OnGUI()
        {
            #if PROFILING_CONSOLE
            if(stopwatch != null)
                stopwatch.Start();
            #endif

            if(Renderer != null)
            {
                if(!Renderer.OnGUI())
                {
                    // re-create this object if something goes wrong during render
                    Renderer = null;
                    InitNonSerializableFields();
                }
            }

            #if PROFILING_CONSOLE
            if(stopwatch != null)
            {
                stopwatch.Stop();
                counterStopwatch++;

                if(counterStopwatch >= 100)
                {
                    UnityEngine.Debug.Log(string.Format("OnGUI() time: {0} ticks, {1} ms after {2} calls", stopwatch.ElapsedTicks, stopwatch.ElapsedMilliseconds, counterStopwatch));
                    stopwatch.Reset();
                    counterStopwatch = 0;
                }
            }
            #endif
        }

        void OnFocus()
        {
            if(Renderer != null)
                Renderer.OnFocus();
        }

        void OnLostFocus()
        {
            if(Renderer != null)
                Renderer.OnLostFocus();
        }

        void InitNonSerializableFields_Early()
        {
            Instance = this;
        }

        void InitSerializableFields()
        {
            // the following fields are always re-serialized correctly whenever the editor enters Play mode or editor is restarted
            base.title = "Console E";
        }

        void InitNonSerializableFields() 
        {
            // some fields are reset whenever the editor enters Play mode or if the editor is restarted, 
            // so we must re-initialize some fields during OnEnable()
            // for better performance, we want to minimize re-initialization, so we check for null
            // to see if re-initialization is really needed

            if(RendererParams == null)
            {
                RendererParams = new RendererParamsImpl();
                #if PROFILING_CONSOLE
                UnityEngine.Debug.Log("Recreated RendererParams");
                #endif
            }

            RendererParams.OnMainWindowEnabled(this);
        }

        public void OnOptionsUpdated(ConsoleE_Options options)
        {
            if(ConsoleE_Options.Instance != options)  // Unity's serializer does not serialize this static variables
                ConsoleE_Options.Instance = options;

            if(RendererParams != null)
                RendererParams.OnOptionsUpdatedPrivate(options);

            if(Renderer != null)
                Renderer.OnOptionsUpdated(options);
        }

        public void OnSelectedEntryChanged(IConsoleE_Entry entry)
        {
            if(RendererParams != null)
                RendererParams.SelectedEntry = entry as ConsoleE_Entry;
        }

        void IHasCustomMenu.AddItemsToMenu(GenericMenu menu)
        {
            ConsoleE_Menus.MainWindowCustomMenu(menu);
        }

        public static bool IsUnityAppVersionGreaterThan(string test) // this function has not yet been tested!
        {
            string version = Application.unityVersion;

            int end = Math.Min(version.Length, test.Length);

            for(int i = 0; i < end; i++)
            {
                char v = version[i];
                char t = test[i];

                if(v > t)
                    return true;
                if(v < t)
                    return false;
            }

            return version.Length >= test.Length;
        }
    }
//}


