// 2014 � Inhuman Games. All rights reserved.
using UnityEngine;
using UnityEditor;
using System;
using System.Collections.Generic;
using System.IO;
using System.Runtime.InteropServices;
using System.Diagnostics;
using System.Reflection;
using System.Xml.Serialization;
using System.Text;
using ConsoleE_Interfaces;

// using namespaces seems to cause Unity (4.2) to not serialize objects as fully, when Editor changes play states.  This could reduce performance slighty and possibly effect stability.
//namespace ConsoleE
//{
    /// <summary>
    /// ConsoleE_Entry represents an entry in the console that is visible.  Instances are only created for visible entries that need to be rendered.
    /// </summary>
    [Serializable]
    public class ConsoleE_Entry : IConsoleE_Entry
    {
        /// <summary>
        /// Text is the entire log entry represented as a single string.  This text is from the original entry (display preferences are not considered).
        /// </summary>
        public string Text { get; private set; }

        /// <summary>
        /// Rows are the callstack rows.  The field 'Text' is split into indiviual lines and stored as an array of rows.  This text is from the original entry (display preferences are not considered).
        /// </summary>
        public string[] Rows { get; private set; }

        /// <summary>
        /// This returns the list of text rows that are actually rendered (in callstack area), including any wrapping (done only in callstack area).
        /// GetCallstackRowTextForRendering() alters the main entry and callstack rows based on preferences.  
        /// Also, if the first line of the callstack is wrapped, we effectively render multiple extra rows of text.
        /// </summary>
        /// <returns>Returns rows of text for rendering (for callstack area or main area).  This never returns null.</returns>
        public string[] RowsRendered
        { 
            get
            {
                if(rowsRendered != null)
                    return rowsRendered;

                string[] rows = !IsWrappingActive ? Rows : RowsWrapped;
                rowsRendered = new string[rows.Length];

                for(int i = 0; i < rows.Length; i++)
                {
                    rowsRendered[i] = GetCallstackRowTextForRendering(rows[i]);
                }

                return rowsRendered;
            }
        }
        string[] rowsRendered;

        /// <summary>
        /// Should a row in the callstack be ignored.  This is determined based on the Wrapper List.
        /// </summary>
        public bool IsRowInWrapperList(int iRow) 
        {
            if(iRow < 0 || iRow >= isRowInWrapperList.Length)
                return false;
            return isRowInWrapperList[iRow];
        }

        bool[] isRowInWrapperList { get; set; }

        /// <summary>
        /// What type of icon should we show when rendering this entry?
        /// </summary>
        public UnityEngine.LogType LogType { get; set; }

        /// <summary>
        /// Unity's internal ID, used for highlighting (aka pinging) items in the project/hierarchy windows.
        /// </summary>
        public int InstanceId { get; set; }

        /// <summary>
        /// Select object by it's unity context, so that the unity inspector shows it.
        /// log entries that are bound to HideInHierarchy-objects can not be pinged, but can be inspected (by selecting them).
        /// </summary>
        public void SelectObjectByInstanceId()
        {
            if(this.InstanceId != 0)
            {
                //review: see if this check is needed
                //if(EditorUtility.InstanceIDToObject(InstanceId) != null)
                {
                    Selection.activeInstanceID = InstanceId;
                }
            }
        }

        public bool IsUnityObjectHiddenInHierarchy
        {
            get
            {
                UnityEngine.Object obj = EditorUtility.InstanceIDToObject(InstanceId);
                return obj != null && ((obj.hideFlags & HideFlags.HideInHierarchy) != 0);
            }
        }

        /// <summary>
        /// Index to the first non-ignored row (based on options.WrapperList). this is the row use refer to when deciding which source file to open.
        /// </summary>
        public int IndexPrimaryRow { get; set; } // index to the first non-ignored row (based on options.WrapperList), this is the row use refer to when deciding which source file to open

        /// <summary>
        /// Index of the row in the callstack row that is selected.
        /// </summary>
        public int IndexCallstackRowSelected
        { 
            get 
            {
                ConsoleE_Renderer renderer = GetRendererIfThisIsSelected();
                if(renderer != null)
                    return renderer.IndexSelectedCallstackRow;
                return -1;
            }
        }

        public bool IsPartialTextSelectionActive
        {
            get 
            { 
                ConsoleE_Renderer renderer = GetRendererIfThisIsSelected();
                if(renderer != null)
                    return renderer.IsPartialTextSelectionActive;
                return false;
            } 
        }

        /// <summary>
        /// IndexTextSelectionRowStart returns index of callstack line containing the first character of selected text.
        /// If this returns -1, no text is selected and the other IndexTextSelection properties should not be used.
        /// IndexTextSelection properties are sorted so that the start always comes before the end.
        /// </summary>
        public int IndexTextSelectionRowStart 
        { 
            get 
            { 
                ConsoleE_Renderer renderer = GetRendererIfThisIsSelected();
                if(renderer != null)
                    return renderer.IndexTextSelectionRowStart;
                return -1;
            } 
        }

        /// <summary>
        /// Returns row of last line of selected text in the callstack.
        /// IndexTextSelection properties are sorted so that the start always comes before the end.
        /// </summary>
        public int IndexTextSelectionRowEnd
        { 
            get 
            { 
                ConsoleE_Renderer renderer = GetRendererIfThisIsSelected();
                if(renderer != null)
                    return renderer.IndexTextSelectionRowEnd;
                return -1;
            } 
        }

        /// <summary>
        /// Returns column of the first character selected for the row IndexTextSelectionRowStart.
        /// -1 means "left to infinity" is selected, int.MaxValue means "right to infinity" is selected.
        /// Start/End are always sorted.
        /// </summary>
        public int IndexTextSelectionColStart
        { 
            get 
            { 
                ConsoleE_Renderer renderer = GetRendererIfThisIsSelected();
                if(renderer != null)
                    return renderer.IndexTextSelectionColStart;
                return -1;
            } 
        }

        /// <summary>
        /// Returns column of last selected character belonging to IndexTextSelectionRowEnd.
        /// -1 means "left to infinity" is selected, int.MaxValue means "right to infinity" is selected.
        /// Start/End are always sorted.
        /// </summary>
        public int IndexTextSelectionColEnd
        { 
            get 
            { 
                ConsoleE_Renderer renderer = GetRendererIfThisIsSelected();
                if(renderer != null)
                    return renderer.IndexTextSelectionColEnd;
                return -1;
            } 
        }

        /// <summary>
        /// Count of repeating entries similar to this one, 0 means Collapse button is not clicked.
        /// </summary>
        public int CollapseCount { get; set; }

        IConsoleE_Options options;

        public void Init(string text, IConsoleE_Options options, IConsoleE_Renderer renderer)
        {
            this.options = options;

            if(text == null)
                text = "";

            Text = text;
            Rows = Text.Split(new char[] {'\n'}, StringSplitOptions.RemoveEmptyEntries); // StringSplitOptions.RemoveEmptyEntries is needed to replace last row which is always empty
            rowsRendered = null; // rebuild later
            isRowInWrapperList = new bool[Rows.Length];

            WrapWidthChecked = -1.0f;

            IndexPrimaryRow = 0;

            MainAreaTextWidthInPixels = 0;

            for(int i = 0; i < 2 && i < Rows.Length; i++)
            {
                float width = renderer.CalcMainEntryTextPixelWidth(Rows[i]);
                if(width > MainAreaTextWidthInPixels)
                    MainAreaTextWidthInPixels = width;
            }

            for(int i = 1; i < Rows.Length; i++)
            {
                isRowInWrapperList[i] = false;
                string row = Rows[i];

                foreach(IConsoleE_IWrapperListEntry e in options.WrapperList.Entries)
                {
                    if(!string.IsNullOrEmpty(e.Text) && row.Contains(e.Text))
                    {
                        isRowInWrapperList[i] = true;
                        break;
                    }
                }

                if(IndexPrimaryRow == 0 && !isRowInWrapperList[i])
                {
                    IndexPrimaryRow = i;
                }
            }
        }

        public void OnOptionsUpdated(IConsoleE_Options options, IConsoleE_Renderer renderer)
        {
            //if(this.options != options)
            {
                Init(Text, options, renderer);
            }
        }

        public string SecondLineDisplayed
        {
            get
            {
                string ret;

                if(options.SkipWrapperListEntries)
                {
                    if(IndexPrimaryRow != 0) // no point in showing the same line twice
                        ret = Rows[IndexPrimaryRow];
                    else
                        ret = "";
                }
                else
                {
                    if(Rows.Length > 1)
                        ret = Rows[1];
                    else
                        ret = "";
                }

                if(options.HideFilePathsInMainArea)
                {
                    ret = options.RemoveFilePathFromEndOfLine(ret);
                }

                return ret;
            }
        }

        /// <summary>
        /// Adjusts texts to show based on the user's preferences.
        /// </summary>
        /// <param name="iRow">Index of the callstack</param>
        /// <param name="useRowsRenderIndex">If this is set to true and text is wrapped, iRow is the index into the wrapped rows array, not the original un-wrapped rows array. If the first line of the callstack is long enough, it gets wrapped.  If this happens, the effective number of rows increases.</param>
        /// <returns>The adjusted entry text, based on the user's preferences.</returns>
        public string GetCallstackRowTextForRendering(int iRow, bool useRowsRenderIndex = true)
        {
            if(iRow < 0)
                return null;

            if(useRowsRenderIndex && IsWrappingActive)
            {
                if(iRow >= RowsRendered.Length)
                    return null;
                return RowsRendered[iRow]; 
            }

            if(iRow >= Rows.Length)
                return null;

            return GetCallstackRowTextForRendering(Rows[iRow]);
        }

        /// <summary>
        /// Adjusts texts to show based on the user's preferences.
        /// </summary>
        /// <returns>The adjusted entry text, based on the user's preferences.</returns>
        public string GetCallstackRowTextForRendering(string textOriginal)
        {
            if(options.HideFilePathsInCallstackArea)
            {
                return options.RemoveFilePathFromEndOfLine(textOriginal);
            }
            return textOriginal;
        }

        public bool ParseCallstackRowForFilename(int iRow, out string filename, out int lineNumber)
        {
            filename = null;
            lineNumber = -1;

            if(iRow < 0 || iRow >= Rows.Length)
                return false;
        
            try
            {
                string entryLine = Rows[iRow];

                int iFilenameStart;
                int iLineEnd;

                if(iRow != 0)  // iRow 0 is special because compiler errors/warnings only go on this line.
                {
                    // this code assumes the string is in the normal callstack format (at end of the line)
                    // example: 
                    // Core.Log:Error(Object, String) (at Assets/Core/Util/Log.cs:132)

                    iLineEnd = entryLine.LastIndexOf(':');

                    if(iLineEnd == -1)
                        return false;

                    if(!int.TryParse(entryLine.Substring(iLineEnd+1, entryLine.Length-iLineEnd-2), out lineNumber))
                        return false;
                
                    iFilenameStart = entryLine.LastIndexOf("(at ");
                    if(iFilenameStart == -1)
                        return false;
                    iFilenameStart += 4;
                }
                else 
                {
                    // compiler errors and warnings are in a different format, these are always on the first row (iRow == 0)
                    // example:
                    // Assets/Game/Components/Controller_U.cs(362,20): warning CS0618: `UnityEngine.Camera.mainCamera' is obsolete: `use Camera.main instead.'

                    iLineEnd = entryLine.IndexOf("): ");

                    if(iLineEnd == -1)
                        return false;

                    iLineEnd = entryLine.LastIndexOf(',', iLineEnd, iLineEnd);

                    if(iLineEnd == -1)
                        return false;

                    int iComma = iLineEnd;

                    iLineEnd = entryLine.LastIndexOf('(', iLineEnd, iLineEnd);

                    if(iLineEnd == -1)
                        return false;

                    if(!int.TryParse(entryLine.Substring(iLineEnd+1, iComma-iLineEnd-1), out lineNumber))
                        return false;
                
                    iFilenameStart = 0;
                }

                filename = entryLine.Substring(iFilenameStart, iLineEnd - iFilenameStart);

                // remove duplicate "Assets" folder
                if(filename.StartsWith("Assets", StringComparison.InvariantCultureIgnoreCase))
                {
                    filename = filename.Substring(7);
                }

                if(!System.IO.Path.IsPathRooted(filename))
                    filename = options.ProjectAssetPath + filename;

                if(!File.Exists(filename))
                    return false;
           }
            catch(Exception)
            {
                // the stack line entry clicked probably doesn't have a file or line number, let's just silently fail
                return false;
            }

            return true;
        }

        public string GetCallstackFilename(int iRow, IConsoleE_PathTypes pathtype)
        {
            string filename;
            int lineNumber;

            if(ParseCallstackRowForFilename(iRow, out filename, out lineNumber))
            {
                if(pathtype == IConsoleE_PathTypes.AbsolutePath)
                {
                    return filename;
                }
                else if(pathtype == IConsoleE_PathTypes.OnlyFilename)
                {
                    return System.IO.Path.GetFileName(filename);
                }
                else if(pathtype == IConsoleE_PathTypes.RelativePath)
                {
                    string prefix = options != null ? options.ProjectAssetPath : Application.dataPath + Path.DirectorySeparatorChar;
                    if(filename.StartsWith(prefix))
                        filename = "Assets" + Path.DirectorySeparatorChar + filename.Substring(prefix.Length).Replace(Path.AltDirectorySeparatorChar, Path.DirectorySeparatorChar);
                    return filename;
                }
            }

            return null;
        }

        public string ParseCallstackRowForWrapperTextTitle(int iRow)
        {
            if(iRow < 0 || iRow >= Rows.Length)
                return null;

            string s = Rows[iRow];

            int iEnd = s.IndexOf("(");
            if(iEnd == -1)
                return null;

            /* for a shorter form:
            int iStart = s.LastIndexOfAny(new char[] { ':', '.' }, iEnd, iEnd+1);
            if(iStart == -1)
                return null;

            int c = iEnd - iStart - 1;
            if(c <= 0)
                return null;

            return s.Substring(iStart+1, iEnd - iStart - 1).TrimEnd(null) + "()";
             */
            s = s.Substring(0, iEnd);
            if(s.Contains("/")) // slashes will cause submenus to appear
                return null;

            int iSpace = s.IndexOf(' '); // not really a function name if there's a space
            if(iSpace != -1 && iSpace != s.Length-1)
                return null;

            return s.Trim();
        }

        public string ParseCallstackRowForIgnoreTextEntry(int iRow)
        {
            return ParseCallstackRowForWrapperTextTitle(iRow);
        }

        /// <summary>
        /// Returns true if row can be opened in an external editor (if the source file can be located on disk).
        /// </summary>
        public bool IsRowOpenable(int iRow)
        { 
            string s;
            int n;
            return ParseCallstackRowForFilename(iRow, out s, out n);
        }

        /// <summary>
        /// Returns true if something happens when row is clicked.  If iRow is 0, we search for the first openable row.
        /// </summary>
        public bool RowHasAction(int iRow)
        {
            if(iRow == 0)
            {
                string filename;
                int lineNumber;
                if(FindFirstOpenableIndex(0, Rows.Length, true, out filename, out lineNumber) != -1)
                    return true;
            }

            return IsRowOpenable(iRow);
        }

        /// <summary>
        /// Returns true if row should be rendered with a grayed-out color, when shown in the callstack
        /// </summary>
        public bool IsRowGrayedOut(int iRow)
        {
            iRow = GetOriginalRowIndexBeforeWrapping(iRow);

            if(IsRowInWrapperList(iRow))
                return true;
            return !RowHasAction(iRow);
        }

        /// <summary>
        /// Search callstack for first entry that can be opened (file is found to exist)
        /// </summary>
        /// <param name="iRowStart">Row to begin searching.</param>
        /// <param name="cMaxRowsChecked">Max number of call stack entries to check.</param>
        /// <param name="skipWrapperRows">If true, this will skip past rows that have a match with an entry in the wrapper list.</param>
        /// <param name="filename">Filename of source file found, or null if not found.</param>
        /// <param name="lineNumber">Line number of source file, or -1 if not found</param>
        /// <returns>Index of row in callstack found to be openable.</returns>
        public int FindFirstOpenableIndex(int iRowStart, int cMaxRowsChecked, bool skipWrapperRows, out string filename, out int lineNumber)
        {
            filename = null;
            lineNumber = -1;

            for(int i = iRowStart; i < iRowStart + cMaxRowsChecked; i++)
            {
                if(i >= Rows.Length)
                    return -1;

                if(skipWrapperRows && isRowInWrapperList[i])
                    continue;

                if(ParseCallstackRowForFilename(i, out filename, out lineNumber))
                {
                    return i;
                }
            }

            return -1;
        }

        ConsoleE_Renderer GetRendererIfThisIsSelected()
        {
            if(ConsoleE_Window.Instance != null)
            {
                ConsoleE_Renderer renderer = ConsoleE_Window.Instance.Renderer;
                if(renderer != null)
                {
                    if(renderer.SelectedEntry == this)
                        return renderer;
                }
            }
            return null;
        }

        /// <summary>
        /// Maximum number of pixels used for the text of the entry when shown in the main area.  The main area text consists of the first two lines of text.
        /// </summary>
        public float MainAreaTextWidthInPixels { get; set; }

        /// <summary>
        /// If the first line of the callstack is very long, it can get wrapped.
        /// </summary>
        public bool IsWrappingActive { get { return RowsWrapped != null; } }

        /// <summary>
        /// If the first line of the callstack is very long, it can get wrapped.  We check for wrapping only when needed (if width of window changes).
        /// </summary>
        /// <returns>The wrapping width value used when we last checked for text wrapping.</returns>
        public float WrapWidthChecked { get; set; }

        /// <summary>
        /// If IsWrappingActive, this converts indexes from RowsWrapped to Rows.  If !IsWrappingActive, this just returns iRow.
        /// </summary>
        public int GetOriginalRowIndexBeforeWrapping(int iRowWrapped)
        {
            if(!IsWrappingActive || iRowWrapped == -1)
                return iRowWrapped;

            if(iRowWrapped < WrapDataPrivate) // WrapDataPrivate is based on the number of rows created by wrapping the first line of text, specifically it's the total of rows the wrapped line becomes
                return 0;

            return iRowWrapped-WrapDataPrivate + 1;
        }

        /// <summary>
        /// If IsWrappingActive, rows of text are created in RowsMapped.  This converts index from Rows to RowsWrapped, note that a non-wrapped index could map to more than one index in RowsWrapped.
        /// </summary>
        /// <param name="iRow">iRow is the non-wrapped index into Rows</param>
        /// <param name="iRowStart">First index in RowsWrapped, when mapping from Rows to RowsWrapped</param>
        /// <param name="iRowEnd">Last index in RowsWrapped, when mapping from Rows to RowsWrapped</param>
        public void GetWrappedIndices(int iRow, out int iRowStart, out int iRowEnd)
        {
            if(!IsWrappingActive || iRow == -1)
            {
                iRowStart = iRow;
                iRowEnd = iRow;
            }
            else
            {
                // we currently only wrap the first line, so we can special-case this for iRow == 0
                if(iRow != 0)
                {
                    iRowStart = iRow + WrapDataPrivate - 1;
                    iRowEnd = iRowStart;
                }
                else
                {
                    iRowStart = 0;
                    iRowEnd = WrapDataPrivate - 1;
                }
            }
        }

        /// <summary>
        /// If the text first line of the callstack is wrapped, we effectively render multiple extra rows of text.
        /// </summary>
        /// <returns>The wrapped version of the original text in found in the Rows array (text from GetCallstackRowTextForRendering)</returns>
        public string[] RowsWrapped 
        { 
            get
            {
                return rowsWrapped;
            }
            set
            {
                rowsRendered = null; // force rebuild
                rowsWrapped = value;
            }
        }
        string[] rowsWrapped;

        /// <summary>
        /// This is used internally by the renderer and should not be used.
        /// </summary>
        public int WrapDataPrivate { get; set; }
    }
//}
