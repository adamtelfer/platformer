// 2014 � Inhuman Games. All rights reserved.
//#define PROFILING_CONSOLE
using UnityEngine;
using UnityEditor;
using System;
using System.Collections.Generic;
using System.IO;
using System.Runtime.InteropServices;
using System.Diagnostics;
using System.Reflection;
using System.Xml.Serialization;
using System.Text;
using ConsoleE_Interfaces;

// using namespaces seems to cause Unity (4.2) to not serialize objects as fully, when Editor changes play states.  This could reduce performance slighty and possibly effect stability.
//namespace ConsoleE
//{
    /// <summary>
    /// ConsoleE_OptionsWindow contains the UI code for showing ConsoleE_Options.
    /// </summary>
    [Serializable]
    public class ConsoleE_OptionsWindow : UnityEditor.EditorWindow
    {
        public static ConsoleE_OptionsWindow Instance;

        public ConsoleE_Options Options { get { return ConsoleE_Options.Instance; } }

        GUIStyle bold;
        //Vector2 scrollPos;
        string wrapperListTextRaw;
        DateTime timeRepaintIgoreListChanges;
        bool wrapperListDirty;

	    public static void ShowWindow()
        {
            ConsoleE_OptionsWindow window = (Instance != null) ? Instance : ScriptableObject.CreateInstance(typeof(ConsoleE_OptionsWindow)) as ConsoleE_OptionsWindow;
            window.minSize = new Vector2(460, 500);
            //window.maxSize = new Vector2(600, 500);
            window.Show();
            window.Focus();
        }

        public static ConsoleE_Options LoadOptions()
        {
            ConsoleE_Options options = new ConsoleE_Options();
            options.Init();
            return options;
        }

        public void ReloadOptions(bool notifyMainWindow, bool refreshOptionsWindow)
        {
            LoadOptions();
            if(notifyMainWindow)
                Options.NotifyUpdated();

            if(refreshOptionsWindow)
            {
                wrapperListTextRaw = null; // force rebuild later
                Repaint();
            }
        }

        public void OnWrapperListUpdated()
        {
            wrapperListTextRaw = null; // force rebuild later
            Repaint();
        }

        void OnEnable()
        {
            Instance = this;

            GUISkin builtin = EditorGUIUtility.GetBuiltinSkin(EditorSkin.Inspector);

            base.title = "Options";
            bold = new GUIStyle(builtin.label);
            bold.fontStyle = FontStyle.Bold;

            ReloadOptions(true, true);
        }

        void OnDisable()
        {
            // if user cancels Window without pressing OK, then revert to previous settings
            // or if the user saved settings, then loading them again will not harm anything
            ReloadOptions(true, false);
        }

        bool TogglePrivate(bool value, ref bool dirty, string text, string tooltip)
        {
            bool previous = value;

            EditorGUILayout.BeginHorizontal();

            GUILayout.Label(new GUIContent(text, tooltip), GUILayout.MinWidth(195.0f), GUILayout.MaxWidth(195.0f));

            value = EditorGUILayout.Toggle(new GUIContent("", tooltip), value, GUILayout.MaxWidth(30.0f));

            EditorGUILayout.EndHorizontal();

            if(previous != value)
                dirty = true;

            return value;
        }

        void Update()
        {
            // allow preview of wrapper list changes, but only after some idle time
            // in case this update is very slow and the user has a lot to type
            if(wrapperListDirty && (DateTime.Now - timeRepaintIgoreListChanges).Seconds >= 2)
            {
                if(wrapperListTextRaw != null)
                {
                    Options.SetWrapperListFromRawText(wrapperListTextRaw);
                    Options.NotifyUpdated();
                    timeRepaintIgoreListChanges = DateTime.Now;
                    wrapperListDirty = false;
                }
            }
        }

	    void OnGUI() 
        {
            //EditorGUIUtility.LookLikeInspector();

            // workaround for this issue: 
            // http://forum.unity3d.com/threads/196601-Editor-TextField-carries-over-text
            if(wrapperListTextRaw == null)
            {
                wrapperListTextRaw = Options.BuildRawTextFromWrapperList();
                GUI.FocusControl("");
            }

            bold.normal.textColor = GUI.skin.label.normal.textColor;

            //GUILayout.FlexibleSpace();
            EditorGUILayout.Space();

            EditorGUILayout.BeginHorizontal();

            EditorGUILayout.TextArea("Preferences", bold);

            GUILayout.FlexibleSpace();

            if(GUILayout.Button("About", GUILayout.MaxWidth(100)))
            {
                string s = "Console Enhanced was created by Mark Currie of Inhuman Games.";

                s += string.Format("\n\nVersion {0}\n", ConsoleE_Renderer.VersionStringDisplayed);

                if(EditorUtility.DisplayDialog("About Console Enhanced", s, "Website", "OK"))
                {
                    Application.OpenURL("http://inhumangames.com/ConsoleE");
                    //Application.OpenURL("\n\nhttps://www.assetstore.unity3d.com/#/search/Console%20Enhanced");
                }
            }

            EditorGUILayout.EndHorizontal();

            EditorGUILayout.Space();

            EditorGUILayout.BeginHorizontal();

            EditorGUILayout.BeginVertical();

            bool dirty = false;

            Options.HideFilePathsInMainArea = TogglePrivate(Options.HideFilePathsInMainArea, ref dirty, "Hide file paths in second line", "The second-line display (of any main entry) sometimes will contain a filename of a source file.  This option will remove the filename and path text from the second line.");

            Options.HideFilePathsInCallstackArea = TogglePrivate(Options.HideFilePathsInCallstackArea, ref dirty, "Hide file paths in callstack entries", "Callstack entries usually contain a filename and path of a source file.  This option will remove the filename, leaving just the function call text.");

            //Options.SkipNonClickableEntries = EditorGUILayout.Toggle("Skip non-clickable entries", Options.SkipNonClickableEntries);

            EditorGUILayout.EndVertical();

            EditorGUILayout.Space();
            EditorGUILayout.Space();

            //EditorGUILayout.HelpBox("Second-Line Display Preferences describe which entry from the callstack will be shown as the second line.", MessageType.None);

            EditorGUILayout.EndHorizontal();

            EditorGUILayout.Space();
            //EditorGUILayout.Space();

            //GUILayout.FlexibleSpace();


            EditorGUILayout.BeginHorizontal();

            EditorGUILayout.BeginVertical(GUILayout.MaxHeight(30.0f));

            //GUILayout.FlexibleSpace();

            bool dirtyDummy = false; // this preference does not require any refresh
            Options.IsOverridingExternalApp = TogglePrivate(Options.IsOverridingExternalApp, ref dirtyDummy, "Override File Open Behavior", "Callstack entries usually contain a filename and path of a source file.  This option will remove the filename, leaving just the function call text.");

            EditorGUILayout.EndVertical();

            EditorGUILayout.Space();

            if(!Options.IsOverridingExternalApp)
                EditorGUILayout.HelpBox("Override Unity's file open behavior to send specific command-line args to your editor. Check the box to see details.", MessageType.None);

            EditorGUILayout.EndHorizontal();



            if(Options.IsOverridingExternalApp)
            {
                EditorGUILayout.BeginHorizontal();

                EditorGUILayout.HelpBox("This feature allows you to override Unity's open file behavior.  External Editor App describes the path to an executable file, and this cannot be blank. Use the Args Format String to specify how arguments are passed to the external editor. string.Format() is used to form the args string. {0}=Filename, {1}=Line Number. An example Args Format String entry is: --args --remote-silent +\"{0}\" \"{1}\"", MessageType.None);

                EditorGUILayout.EndHorizontal();

                EditorGUILayout.BeginHorizontal();

                //OverrideExternalApp { get; set; }

                Options.OverrideExternalApp = EditorGUILayout.TextField("External Editor App", Options.OverrideExternalApp);

                EditorGUILayout.EndHorizontal();

                EditorGUILayout.BeginHorizontal();
            
                Options.OverrideArgsFormatString = EditorGUILayout.TextField("Args Format String", Options.OverrideArgsFormatString);

                EditorGUILayout.EndHorizontal();

                EditorGUILayout.Space();
            }

            GUILayout.FlexibleSpace();
            GUILayout.FlexibleSpace();

            EditorGUILayout.BeginHorizontal();

            EditorGUILayout.BeginVertical(GUILayout.MaxHeight(30.0f));

            GUILayout.FlexibleSpace();

            EditorGUILayout.TextArea("Wrapper Function List", bold);

            EditorGUILayout.EndVertical();

            EditorGUILayout.Space();

            EditorGUILayout.HelpBox("When clicked, the console will open source file belonging to the first non-wrapper function in the callstack.", MessageType.None);

            EditorGUILayout.EndHorizontal();
            //EditorGUILayout.Space();

            EditorGUILayout.Space();

            //EditorGUILayout.BeginHorizontal();

            Options.SkipWrapperListEntries = TogglePrivate(Options.SkipWrapperListEntries, ref dirty, "Hide wrappers from second line", "Items from the wrapper function list will not be shown in the second-line display (of any main entry).");

            EditorGUILayout.Space();

            //EditorGUIUtility.LookLikeControls();

     //       GUILayout.BeginArea(new Rect(0, GUILayoutUtility.GetLastRect().yMax + 120.0f, Screen.width, 200), styleSeperator);

            EditorGUILayout.BeginHorizontal();

            //GUI.SetNextControlName("WrapperList");
            string textPrevious = wrapperListTextRaw;

            float minHeight = Options.IsOverridingExternalApp ? Mathf.Max(180.0f, Screen.height * 0.90f - 270.0f) : Mathf.Max(280.0f, Screen.height * 0.90f - 200.0f);

            wrapperListTextRaw = EditorGUILayout.TextArea(wrapperListTextRaw, GUILayout.MinWidth(Screen.width - 140), GUILayout.MinHeight(minHeight));
            if(textPrevious != wrapperListTextRaw)
            {
                timeRepaintIgoreListChanges = DateTime.Now;
                wrapperListDirty = true;
            }

            EditorGUILayout.HelpBox("Example entries:\n\nUnityEngine.Debug:Log\n:OnLog(\n:Assert(", MessageType.None);

            EditorGUILayout.EndHorizontal();

            EditorGUILayout.Space();

            EditorGUILayout.BeginHorizontal();
            //GUILayout.Space(Screen.width - 100);
            GUILayout.FlexibleSpace();

            if(GUILayout.Button("OK", GUILayout.MaxWidth(100)))
            {
                bool exception = false;
                try
                {
                    Options.SetWrapperListFromRawText(wrapperListTextRaw);
                    Options.Save();
                }
                catch(Exception e)
                {
                    exception = true;
                    string filename = ConsoleE_Options.GetWrapperListFilenameWithPath();
                    EditorUtility.DisplayDialog("File Error", "Error while try to save changes to: " + Environment.NewLine + filename + Environment.NewLine + Environment.NewLine + e.Message, "OK");
                    throw e;
                }

                if(!exception)
                {
                    this.Close();
                    // no need to load here, load will already happen in OnDisable()....
                    //ReloadOptions();
                }
            }

            EditorGUILayout.EndHorizontal();

            EditorGUILayout.Space();

            if(dirty)
            {
                Options.NotifyUpdated();
            }
        }
    }
//}

