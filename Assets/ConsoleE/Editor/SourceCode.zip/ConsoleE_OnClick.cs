// 2014 � Inhuman Games. All rights reserved.
using UnityEngine;
using UnityEditor;
using System;
using System.Collections.Generic;
using System.IO;
using System.Runtime.InteropServices;
using System.Diagnostics;
using System.Reflection;
//using ConsoleE_Interfaces;

namespace ConsoleE_Interfaces
{
}

// using namespaces seems to cause Unity (4.2) to not serialize objects as fully, when Editor changes play states.  This could reduce performance slighty and possibly effect stability.
//namespace ConsoleE
//{
    /// <summary>
    /// ConsoleE_OnClick is provided to allow you to override the default behavior of how files are opened.
    /// </summary>
    [Serializable]
    public class ConsoleE_OnClick : IConsoleE_OnClick
    {
        IConsoleE_Renderer consoleRenderer;

        /* no custom constructors!  Unity's serializer does not like this.  Use Init() instead.
        public ConsoleE_OnClick()
        {
        }
        */

        public void Init(IConsoleE_Renderer console)
        {
            this.consoleRenderer = console;
            console = this.consoleRenderer; // no-op here to remove warning CS0414: The private field `ConsoleE_OnClick.console' is assigned but its value is never used
        }

        public void OnMainWindowEnabled(IConsoleE_Renderer console)
        {
            this.consoleRenderer = console;
        }

        public IConsoleE_OnClickParams CreateOnClickParams()
        {
            return new OnClickParams();
        }

        public class OnClickParams : IConsoleE_OnClickParams
        {
            /// <summary>
            /// Entry clicked by user.
            /// </summary>
            public IConsoleE_Entry EntryClicked { get; set; }

            /// <summary>
            /// Describes which row in the callstack did the user chose to open.  If main area of the window is clicked, this value is the first non-wrapper function in the callstack (where the file in the callstack entry was found to exist locally).
            /// </summary>
            public int IndexRowSelected { get; set; }

            /// <summary>
            /// Filename that should be opened by the external editor, or null if no filename was found.  This is determined by parsing the callstack and considering the wrapper list.
            /// </summary>
            public string Filename { get; set; }

            /// <summary>
            /// Line number that should be opened by the external editor, or -1 if line number was not found.  This is determined by parsing the callstack and considering the wrapper list.
            /// </summary>
            public int LineNumber { get; set; }

            /// <summary>
            /// Reserverd for future use.  Currently this is always zero.  A future version of ConsoleE may set the column number.
            /// </summary>
            public int ColumnNumber { get; set; }

            /// <summary>
            /// Describes which part of the window was clicked.
            /// </summary>
            public IConsoleE_WindowArea WindowType { get; set; }

            /// <summary>
            /// Null means use default external editor.  User chose to "Open with" from the right-click menu of editors to choose from.  This is the path of the editor's executable file, which comes from Unity's preferences window.
            /// </summary>
            public string ExternalEditorPath { get; set; }

            /// <summary>
            /// If "Open with" is used, this is the index of the entry chosen.  For normal Open commands, this is zero.
            /// </summary>
            public int IndexOpenWithOption { get; set; }
        }

        public void OnClick(IConsoleE_OnClickParams p)
        {
            bool failed = false;

            if(p.Filename != null) // don't crash Unity 3.X
            {
                if(p.IndexOpenWithOption == 0 && ConsoleE_Options.Instance != null && ConsoleE_Options.Instance.IsOverridingExternalApp && !string.IsNullOrEmpty(ConsoleE_Options.Instance.OverrideExternalApp))
                {
                    System.Diagnostics.Process.Start(ConsoleE_Options.Instance.OverrideExternalApp, string.Format(ConsoleE_Options.Instance.OverrideArgsFormatString, p.Filename, p.LineNumber));
                }
                else
                {
                    string relative = p.Filename;
                    string currentDirectory = Directory.GetCurrentDirectory().Replace('\\','/') + "/";
                    if (relative.StartsWith(currentDirectory))
                        relative = relative.Substring(currentDirectory.Length);
                    UnityEngine.Object asset = AssetDatabase.LoadAssetAtPath(relative, typeof(TextAsset));
                    if (asset != null)
                        AssetDatabase.OpenAsset(asset, p.LineNumber);
                    else
                        failed = true;

                    /* This is a legacy way of opening files:
                    if(!UnityEditorInternal.InternalEditorUtility.OpenFileAtLineExternal(p.Filename, p.LineNumber))
                    {
                        UnityEngine.Debug.LogWarning(string.Format("Failed to properly open {0}:{1}", p.Filename, p.LineNumber));
                        failed = true;
                    }
                     */
                }
            }
            else
            {
                failed = true;
            }

            // matches the Unity Console's behaviour of selecting the context object when there is one and no call stack is attached.
            if(failed)
            {
                p.EntryClicked.SelectObjectByInstanceId();
            }
        }
    }
//}
